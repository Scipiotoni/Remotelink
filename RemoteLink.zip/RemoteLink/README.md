# RemoteLink

Control your Windows PC from your school Chromebook, from anywhere. The Chromebook only needs a web page: nothing gets installed on it.

```
Chromebook (web page) ──► handshake via Supabase (a few seconds) ──► Windows PC (tray app)
         ▲                                                                  │
         └──── video + sound (GPU-encoded H.264) / mouse + keyboard ◄───────┘
                      direct peer-to-peer, or via the Cloudflare relay
```

---

## 1. Set up the PC (once, ~10 minutes)

1. Unzip this folder somewhere permanent, e.g. `Documents\RemoteLink`.
2. Open the `host` folder and double-click **`install.bat`**.
   * If Node.js is missing, it installs it, then asks you to run `install.bat` again.
3. The **settings window** opens:
   * **Name** for this PC.
   * **Password**: 10+ characters, one you don't use anywhere else.
   * **Authenticator**: install Google Authenticator / Microsoft Authenticator / 2FAS on your phone, scan the QR, and type the 6-digit code to check it.
   * **Relay (recommended)**: needed if the school network blocks direct connections. Create a free Cloudflare account, go to **Realtime → TURN Server → Create**, then paste the *Turn Token ID* and *API Token* and press **Test**.
   * **Phone alerts (optional)**: install the free **ntfy** app and subscribe to a hard-to-guess topic name. Type that same name here.
   * Press **Save**. Write down the **pairing code** it shows.
4. Windows settings that matter:
   * **Settings → Accounts → Sign-in options → "If you've been away, when should Windows require you to sign in again?" → Never.** Remote control can't get past the Windows lock screen.
   * Don't press Win+L before you leave the PC.
   * The tray icon may be hidden under the **^** arrow next to the clock. Drag it onto the taskbar so you can see its colour:
     * cyan = ready
     * pink = session active
     * amber = paused
     * grey = offline

RemoteLink starts with Windows and keeps the PC awake. You can change both in the tray menu.

## 2. Put the Chromebook page online (once)

The `client` folder is the website: `app.html` (the whole Chromebook app in one file), `index.html` (landing page) and `RemoteLink.zip` (the PC app download). Nothing in it is secret, so a public host is fine.

**GitHub Pages:**
1. Create a new repository (e.g. `remotelink`).
2. Upload everything in the `client` folder (`index.html`, `app.html`, `RemoteLink.zip`).
3. Go to **Settings → Pages → Deploy from branch → main**.
4. You get `https://YOURNAME.github.io/remotelink/`.

On the Chromebook, open the page and press **Open RemoteLink** (or go straight to `…/app.html` and bookmark it). You can also paste the URL into the PC settings ("Chromebook page"). It then shows a one-click pairing link and a QR code; the Chromebook's Camera app can scan QR codes.

## 3. Connect from the Chromebook

1. Open your page and type the pairing code once.
2. **First time:** type your **password** and the **6-digit code** from your phone. Leave **"Remember this Chromebook"** ticked. It connects as soon as the 6th digit is typed.
3. **After that:** just the password + Enter. The Chromebook keeps a secret "trusted device" key, so the code isn't needed again.

| Hold **Ctrl+Alt+Shift** and press | Does |
|---|---|
| **F** | full screen (hold **Esc** to leave) |
| **G** | switch Desktop ⇄ Game mode |
| **S** | stats (latency, fps, bitrate, direct/relay) |
| **H** | pin the toolbar (otherwise: move the mouse to the top edge) |
| **T** | type text on the PC |
| **M** | sound on/off |
| **Q** | disconnect |

* **Desktop mode**: sharp text, normal mouse.
* **Game mode**: smooth motion. Click to capture the mouse so games can turn the camera; press Esc to release it.
* In full screen, Alt+Tab and the **Search key (= Windows key)** go to the PC.
* The toolbar's **Keys** menu has F1–F12, Ctrl+Shift+Esc, Win+D and similar.
* **Clipboard** copies text between the Chromebook and the PC.
* If Wi-Fi drops, it reconnects by itself for up to 10 minutes without asking for a new code.

## Let friends use it (everyone on their own PC, at the same time)

Each person controls **their own** PC from **their own** Chromebook. Everyone gets a separate private room, password and code, so nobody can see or control anyone else's PC.

1. Make sure **`RemoteLink.zip`** is in your GitHub repo (next to `index.html`). The landing page and the app's pairing screen both link to it.
2. Send friends your page link. Each friend:
   * opens it on their PC and downloads the app;
   * runs `install.bat`, sets **their own** password and authenticator;
   * pairs **their** Chromebook with **their** PC's code.
3. That's it. All of you share your free Supabase project for the few-second handshake. It allows around 200 PCs online at once, far more than you need.
4. The Cloudflare relay uses the account of whoever set it up, so each friend should create **their own** free Cloudflare relay in their settings. Don't share yours.

## Security

* **Two factors**: your password *and* a code that changes every 30 s (the standard all authenticator apps use; each code is accepted for about a minute). After that one code login, a Chromebook you chose to remember keeps a 256-bit device key, so the password + that key is enough. Without the key (another device) the code is still required.
* **Trusted Chromebooks** are listed in the PC settings (tray → *Settings & pairing*), where you can remove any of them. The panic key, a new password or a new authenticator removes them all.
* **The password never travels.** The Chromebook only sends a one-time proof of it.
* **Everything is encrypted**: the handshake with AES-256-GCM using a key derived from your password and the current code, and the stream itself by WebRTC.
* **Lockout**: 5 wrong tries lock logins for 15 minutes, doubling each time.
* **No open ports** on your router.
* **Panic key on the PC: `Ctrl+Alt+Shift+K`.** It ends the session at once and blocks all logins until you click *Resume* in the tray.
* **View-only mode**, enforced on the PC, not just in the page. You can also untick *Allow control* to make every session view-only.
* **Idle disconnect** (20 min by default).
* **On-screen badge**: anyone sitting at the PC sees that a session is active. The badge is hidden from the stream.
* **Alerts** on every login, failed attempt and lockout: Windows notification, plus phone push if you set up ntfy.
* **Activity log**: tray menu → *Activity log* (`%APPDATA%\RemoteLink\activity.log`).
* **Secrets are stored encrypted** with Windows' own protection (DPAPI). The settings window can't be seen through the stream, and you need the password to open it.

**Remember:** school Chromebooks are usually monitored, and the trusted-device key is saved in that Chromebook's browser. Use a strong password, and remove the Chromebook in settings if you stop using it. The school can see what is on your screen, including your PC's screen. Don't type important passwords through it, and check your school's rules about remote access.

## Troubleshooting

| Problem | Fix |
|---|---|
| "Your PC didn't answer" | The PC must be on, awake and online, with the tray icon cyan. |
| "Can't reach the signaling server" | The network blocks `supabase.co`. Try another network or a phone hotspot. |
| "The stream didn't start" | The network blocks direct video connections. Set up the Cloudflare relay (step 1.3). |
| Black screen | The PC is on the lock screen or showing an admin (UAC) prompt. Windows doesn't allow either to be controlled remotely. |
| Laggy | Stats (Ctrl+Alt+Shift+S): *relay* adds a little latency. Lower Bandwidth to *Balanced* or use 30 fps on weak Wi-Fi. A cable on the PC helps. |
| No phone alerts | Check the ntfy topic is exactly the same on both sides; use *Send test*. |

The handshake uses a free Supabase project (`remote-link`) in your account. The PC pings it daily so it never pauses. If the PC is off for more than a week, open the Supabase dashboard and press **Restore** on the project.
