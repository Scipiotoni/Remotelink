// Shared TURN relay for RemoteLink. Deploy from this folder with:  cf deploy
// The TURN key is uploaded as secrets (TURN_KEY_ID, TURN_KEY_TOKEN) with --secrets-file, never stored here.
import { bindings, defineConfig } from "cf/config";

export default defineConfig({
  worker: {
    name: "remotelink-relay",
    entrypoint: "./src/index.js",
    compatibilityDate: "2026-11-01",
    workersDev: true,
    env: {
      TURN_KEY_ID: bindings.secret(),
      TURN_KEY_TOKEN: bindings.secret(),
      ANALYTICS_TOKEN: bindings.secret(), // "Account Analytics Read" only, to stay inside the free 1,000 GB/month
      ACCOUNT_ID: bindings.text("7e4a8771aa13c8d4e3b5be03df1e83b8"),
      MONTHLY_GB: bindings.text("800"),
      DAILY_LIMIT: bindings.text("500"),
      DISABLED: bindings.text("0"),
      USAGE: bindings.kv(),
      PER_IP: bindings.rateLimit({ namespace: "1001", simple: { limit: 5, period: 60 } }),
    },
  },
});
