// RemoteLink shared relay: hands out short-lived Cloudflare TURN credentials to RemoteLink PCs,
// so nobody has to create their own Cloudflare account. The TURN key lives only in this Worker's
// secrets (TURN_KEY_ID, TURN_KEY_TOKEN); PCs only ever see credentials that expire after TTL seconds.
//
// Abuse limits: a few requests per minute per IP (rate-limit binding), a daily total (KV counter),
// and a kill switch (set the DISABLED variable to "1" and redeploy).
//
// Staying free: Cloudflare TURN is free up to 1,000 GB a month. Before handing out credentials the Worker
// reads this month's TURN egress for the whole account (GraphQL analytics, token ANALYTICS_TOKEN with
// "Account Analytics Read" only) and stops at MONTHLY_GB, leaving room for sessions already running.
// If the usage can't be read and nothing recent is cached, it refuses: never risk a bill.

const TTL = 6 * 3600;
const USAGE_FRESH_MS = 10 * 60e3;

let memUsage = null; // { month, bytes, at } — per-isolate cache in front of KV

async function monthEgressBytes(env) {
  const now = new Date();
  const month = now.toISOString().slice(0, 7);
  if (memUsage && memUsage.month === month && Date.now() - memUsage.at < USAGE_FRESH_MS) return memUsage.bytes;
  let cached = null;
  if (env.USAGE) { try { cached = JSON.parse(await env.USAGE.get('egress:' + month) || 'null'); } catch (e) { cached = null; } }
  if (cached && Date.now() - cached.at < USAGE_FRESH_MS) { memUsage = Object.assign({ month }, cached); return cached.bytes; }
  try {
    const r = await fetch('https://api.cloudflare.com/client/v4/graphql', {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.ANALYTICS_TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: `query($a: string!, $from: Date!, $to: Date!) { viewer { accounts(filter: { accountTag: $a }) {
          callsTurnUsageAdaptiveGroups(filter: { date_geq: $from, date_leq: $to }, limit: 1) { sum { egressBytes } } } } }`,
        variables: { a: env.ACCOUNT_ID, from: month + '-01', to: now.toISOString().slice(0, 10) },
      }),
    });
    const j = await r.json();
    if (!r.ok || (j.errors && j.errors.length)) throw new Error('analytics HTTP ' + r.status);
    const groups = j.data.viewer.accounts[0].callsTurnUsageAdaptiveGroups || [];
    const bytes = groups.reduce((n, g) => n + (Number(g.sum && g.sum.egressBytes) || 0), 0);
    const rec = { bytes, at: Date.now() };
    memUsage = Object.assign({ month }, rec);
    if (env.USAGE) await env.USAGE.put('egress:' + month, JSON.stringify(rec), { expirationTtl: 40 * 86400 });
    return bytes;
  } catch (e) {
    if (cached && Date.now() - cached.at < 6 * 3600e3) return cached.bytes; // analytics hiccup: last reading is fine
    return null; // unknown
  }
}

const json = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});

async function overDailyLimit(env) {
  if (!env.USAGE) return false;
  const key = 'day:' + new Date().toISOString().slice(0, 10);
  const n = Number(await env.USAGE.get(key)) || 0;
  const limit = Number(env.DAILY_LIMIT) || 500;
  if (n >= limit) return true;
  await env.USAGE.put(key, String(n + 1), { expirationTtl: 3 * 86400 });
  return false;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== '/ice') return new Response('RemoteLink relay. Nothing to see here.\n', { headers: { 'Content-Type': 'text/plain' } });
    if (request.method !== 'POST' || request.headers.get('X-RemoteLink') !== '1') return json(400, { error: 'bad request' });
    if (env.DISABLED === '1') return json(503, { error: 'The shared relay is switched off.' });
    if (!env.TURN_KEY_ID || !env.TURN_KEY_TOKEN) return json(503, { error: 'The shared relay is not set up.' });

    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    if (env.PER_IP) {
      const { success } = await env.PER_IP.limit({ key: ip });
      if (!success) return json(429, { error: 'Too many requests, try again in a minute.' });
    }
    const used = await monthEgressBytes(env);
    if (used == null) return json(503, { error: 'The shared relay could not check its free monthly allowance. Try again in a few minutes.' });
    if (used >= (Number(env.MONTHLY_GB) || 800) * 1e9) return json(429, { error: 'The shared relay used up its free allowance for this month. It comes back on the 1st, or add your own free Cloudflare relay in the PC settings.' });
    if (await overDailyLimit(env)) return json(429, { error: 'The shared relay reached its daily limit. Try again tomorrow, or add your own Cloudflare relay in the PC settings.' });

    const r = await fetch(`https://rtc.live.cloudflare.com/v1/turn/keys/${encodeURIComponent(env.TURN_KEY_ID)}/credentials/generate-ice-servers`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.TURN_KEY_TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ttl: TTL }),
    });
    if (!r.ok) return json(502, { error: 'Cloudflare answered HTTP ' + r.status });
    const j = await r.json();
    const iceServers = (Array.isArray(j.iceServers) ? j.iceServers : [j.iceServers]).filter(Boolean)
      // browsers refuse port 53, so drop those URLs (as Cloudflare recommends)
      .map((s) => Object.assign({}, s, { urls: [].concat(s.urls).filter((u) => !/:53(\?|$)/.test(u)) }))
      .filter((s) => s.urls.length);
    return json(200, { iceServers, ttl: TTL });
  },
};
