'use strict';
/* RemoteLink host — runs on the Windows PC, lives in the system tray.
 * Waits on the signaling channel; when your Chromebook logs in (password + authenticator code)
 * it streams the screen over WebRTC and injects your mouse/keyboard with SendInput. */
const {
  app, BrowserWindow, Tray, Menu, ipcMain, globalShortcut, Notification, screen, desktopCapturer,
  safeStorage, clipboard, shell, powerSaveBlocker, powerMonitor, session: eSession,
} = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const WebSocket = require('ws');
const QRCode = require('qrcode');
const P = require('./lib/proto');
const SignalHost = require('./lib/signal-host');
const { createInjector } = require('./lib/input-win');

const APP_NAME = 'RemoteLink';
const DEFAULT_SIGNAL = { url: 'https://sbpbamajbbwuxjjcnkkl.supabase.co', key: 'sb_publishable_x9imtiSPZ9dPatRD__5rBA_adoHUHvZ' };
const PANIC_KEY = 'Control+Alt+Shift+K';
const HIDDEN = process.argv.includes('--hidden');
const TEST = process.env.RL_TEST === '1';

app.setName(APP_NAME);
if (process.platform === 'win32') app.setAppUserModelId('RemoteLink.Host');
if (process.env.RL_DATA_DIR) app.setPath('userData', process.env.RL_DATA_DIR);

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => openSetup());
}

const dataDir = () => app.getPath('userData');
const CFG = () => path.join(dataDir(), 'config.json');
const STATE = () => path.join(dataDir(), 'state.json');
const LOG = () => path.join(dataDir(), 'activity.log');
const asset = (n) => path.join(__dirname, 'assets', n);

let cfg = null;            // config (+ cfg.secrets decrypted, in memory only)
let tray = null, captureWin = null, badgeWin = null, setupWin = null;
let host = null;           // SignalHost
let session = null;        // active remote session
let signalStatus = 'off';
let lastIce = [];
let keepAwakeId = null, displayAwakeId = null, idleTimer = null;
let setupUnlocked = false, unlockFails = 0, unlockBlockedUntil = 0;

const injector = createInjector({
  log: TEST ? (kind, v) => process.stdout.write(`[inject] ${kind} ${JSON.stringify(v)}\n`) : null,
  onError: (e) => logLine('INPUT-ERROR', String(e && e.message)),
});

// ---------------------------------------------------------------- storage
function readJSON(p, def) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { return def; } }
function writeJSON(p, obj) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  const tmp = p + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, p);
}
function sealSecrets(obj) {
  const json = JSON.stringify(obj);
  if (safeStorage.isEncryptionAvailable()) return { enc: 'os', data: safeStorage.encryptString(json).toString('base64') };
  return { enc: 'none', data: Buffer.from(json).toString('base64') };
}
function openSecrets(s) {
  const buf = Buffer.from(s.data, 'base64');
  return JSON.parse(s.enc === 'os' ? safeStorage.decryptString(buf) : buf.toString('utf8'));
}
function loadConfig() {
  const raw = readJSON(CFG(), null);
  if (!raw || !raw.secure) return null;
  try { raw.secrets = openSecrets(raw.secure); } catch (e) { logLine('CONFIG-ERROR', 'cannot decrypt secrets: ' + e.message); return null; }
  delete raw.secure;
  return raw;
}
function saveConfig(c) {
  const pub = Object.assign({}, c);
  delete pub.secrets;
  pub.secure = sealSecrets(c.secrets);
  writeJSON(CFG(), pub);
}

function logLine(event, detail) {
  const d = new Date();
  const ts = `${d.toLocaleDateString()} ${d.toLocaleTimeString()}`;
  const line = `${ts}  ${event.padEnd(16)} ${detail || ''}\n`;
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    fs.appendFileSync(LOG(), line);
    const st = fs.statSync(LOG());
    if (st.size > 1024 * 1024) fs.writeFileSync(LOG(), fs.readFileSync(LOG(), 'utf8').slice(-512 * 1024));
  } catch (e) { /* ignore */ }
  if (TEST) process.stdout.write('[log] ' + line);
}
const short = (sid) => String(sid || '').slice(0, 6);

function alert(body, important) {
  try {
    if (Notification.isSupported()) new Notification({ title: APP_NAME, body, silent: !important, icon: asset('icon.png') }).show();
  } catch (e) { /* ignore */ }
  if (cfg && cfg.ntfyTopic) {
    fetch(`https://ntfy.sh/${encodeURIComponent(cfg.ntfyTopic)}`, {
      method: 'POST', body: `${cfg.name}: ${body}`,
      headers: { Title: APP_NAME, Priority: important ? 'high' : 'default', Tags: important ? 'warning' : 'computer' },
    }).catch(() => {});
  }
}

// ---------------------------------------------------------------- displays
function physRect(d) {
  if (process.platform === 'win32') {
    try { return screen.dipToScreenRect(null, d.bounds); } catch (e) { /* fall through */ }
  }
  const f = d.scaleFactor || 1;
  return { x: Math.round(d.bounds.x * f), y: Math.round(d.bounds.y * f), width: Math.round(d.bounds.width * f), height: Math.round(d.bounds.height * f) };
}
function listDisplays() {
  const prim = screen.getPrimaryDisplay().id;
  return screen.getAllDisplays().map((d, i) => {
    const r = physRect(d);
    return { id: String(d.id), name: d.label || `Display ${i + 1}`, primary: d.id === prim, w: r.width, h: r.height };
  });
}
async function sourceFor(display) {
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } });
  const src = sources.find((x) => String(x.display_id) === String(display.id)) || sources[0];
  if (!src) return null;
  const r = physRect(display);
  return { sourceId: src.id, displayId: String(display.id), width: r.width, height: r.height };
}

// ---------------------------------------------------------------- TURN relay
async function turnServers(keyId, token) {
  const r = await fetch(`https://rtc.live.cloudflare.com/v1/turn/keys/${encodeURIComponent(keyId)}/credentials/generate-ice-servers`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ ttl: 6 * 3600 }),
    signal: AbortSignal.timeout(7000),
  });
  if (!r.ok) throw new Error('Cloudflare answered HTTP ' + r.status);
  const j = await r.json();
  const list = (Array.isArray(j.iceServers) ? j.iceServers : [j.iceServers]).filter(Boolean)
    // browsers refuse port 53, so drop those URLs (as Cloudflare recommends)
    .map((s) => Object.assign({}, s, { urls: [].concat(s.urls).filter((u) => !/:53(\?|$)/.test(u)) }))
    .filter((s) => s.urls.length);
  if (!list.length) throw new Error('Cloudflare returned no servers');
  return list;
}
async function getIceServers() {
  const base = [{ urls: ['stun:stun.cloudflare.com:3478', 'stun:stun.l.google.com:19302'] }];
  const keyId = cfg && cfg.turn && cfg.turn.keyId;
  const token = cfg && cfg.secrets.turnToken;
  if (!keyId || !token) return base;
  try { return await turnServers(keyId, token); } catch (e) {
    logLine('TURN-ERROR', e.message + ' (direct connection only)');
    return base;
  }
}

// ---------------------------------------------------------------- trusted Chromebooks
// After one login with the authenticator code, a Chromebook can be remembered: it gets a random
// 256-bit key, and from then on password + that key is enough. Keys live in the encrypted secrets.
const MAX_DEVICES = 10;
const deviceList = () => (cfg && cfg.secrets.devices) || [];
const devicesApi = {
  get(id) {
    const d = deviceList().find((x) => x.id === id);
    return d ? { key: P.unb64(d.key), name: d.name } : null;
  },
  add(name) {
    const list = (cfg.secrets.devices = deviceList());
    const key = P.rand(32);
    const id = P.b64(P.rand(9));
    list.push({ id, key: P.b64(key), name, created: Date.now(), lastUsed: Date.now() });
    list.sort((a, b) => b.lastUsed - a.lastUsed);
    if (list.length > MAX_DEVICES) list.length = MAX_DEVICES;
    saveConfig(cfg);
    return { id, key, name };
  },
  touch(id) {
    const d = deviceList().find((x) => x.id === id);
    if (d) { d.lastUsed = Date.now(); saveConfig(cfg); }
  },
};
function forgetDevices(why, id) {
  if (!cfg) return;
  const before = deviceList().length;
  cfg.secrets.devices = id ? deviceList().filter((d) => d.id !== id) : [];
  saveConfig(cfg);
  if (before !== cfg.secrets.devices.length) logLine('DEVICES', `${id ? 'removed one' : 'removed all'} trusted Chromebook(s) — ${why}`);
  updateTray();
}

// ---------------------------------------------------------------- signaling host
function startHost() {
  stopHost();
  if (!cfg) return;
  const sec = cfg.secrets;
  const decoded = { K: P.unb64(sec.K), salt: sec.salt, iter: sec.iter, totp: P.base32Decode(sec.totp) };
  host = new SignalHost({
    signal: cfg.signal,
    secrets: () => decoded,
    store: { load: () => readJSON(STATE(), {}), save: (s) => writeJSON(STATE(), s) },
    iceServers: async () => (lastIce = await getIceServers()),
    info: () => ({ name: cfg.name, displays: listDisplays() }),
    allowControl: () => cfg.allowControl !== false,
    devices: devicesApi,
    WebSocket,
  });
  host.setPaused(!!cfg.paused);
  host.on('status', (s, d) => {
    if (s !== signalStatus) logLine('SIGNAL', s + (d ? ' ' + JSON.stringify(d) : ''));
    signalStatus = s; updateTray();
  });
  host.on('log', (t) => logLine('SIGNAL', t));
  host.on('attempt', onAttempt);
  host.on('locked', ({ until }) => {
    logLine('LOCKED', 'until ' + new Date(until).toLocaleString());
    alert(`Remote logins LOCKED after too many wrong attempts (until ${new Date(until).toLocaleTimeString()}).`, true);
    updateTray();
  });
  host.on('auth', onAuth);
  host.on('secure', onSecure);
  host.start();
}
function stopHost() {
  if (session) teardown('host-restarted', false);
  if (host) { host.removeAllListeners(); host.stop(); host = null; }
  signalStatus = 'off';
}

function onAttempt(a) {
  if (a.ok) {
    const dev = a.device ? (a.device.isNew ? ` — "${a.device.name}" is now a trusted Chromebook` : ` via trusted Chromebook "${a.device.name}"`) : '';
    logLine('LOGIN-OK', `session ${short(a.sid)}${a.viewOnly ? ' view-only' : ''}${a.resumed ? ' (reconnect)' : ''}${dev}`);
    if (a.device && a.device.isNew) alert(`New trusted Chromebook: "${a.device.name}". It can now log in with just the password. Remove it in Settings if that wasn't you.`, true);
    else if (!a.resumed) alert(`Remote session started${a.viewOnly ? ' (view only)' : ''}. Press Ctrl+Alt+Shift+K to cut it off.`, false);
  } else if (a.reason === 'paused') {
    logLine('LOGIN-BLOCKED', 'remote access is paused');
  } else if (a.reason === 'unknown-device') {
    logLine('LOGIN-FAILED', 'Chromebook is no longer trusted (it must use the code again)');
  } else {
    logLine('LOGIN-FAILED', `wrong password or code (${a.mode === 'resume' ? 'reconnect token' : 'login'})`);
    if (!a.locked) alert('Failed remote login attempt (wrong password or code).', true);
  }
}

function onAuth({ sid, viewOnly, resumed }) {
  if (session) teardown('replaced', false);
  const prim = screen.getPrimaryDisplay();
  session = {
    sid, viewOnly, resumed, started: Date.now(), lastActivity: Date.now(), ice: lastIce,
    display: prim, rect: physRect(prim), route: null,
  };
  setDisplayAwake(true);
  try { injector.moveRel(1, 0); injector.moveRel(-1, 0); } catch (e) { /* wakes a sleeping monitor */ }
  showBadge(true);
  startIdleTimer();
  updateTray();
}

function onSecure({ sid, msg }) {
  if (!session || session.sid !== sid) return;
  if (msg.t === 'ready') startCapture(msg.prefs || {}).catch((e) => {
    logLine('CAPTURE-ERROR', e.message);
    teardown('capture-failed', false);
  });
  else if (msg.t === 'answer' || msg.t === 'ice') sendCapture({ t: 'signal', msg });
  else if (msg.t === 'bye') teardown('client-disconnected', false);
}

function cleanPrefs(p) {
  const num = (v, lo, hi, d) => (typeof v === 'number' && isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d);
  return {
    mode: p.mode === 'game' ? 'game' : 'desktop',
    codec: ['h264', 'vp9', 'av1', 'vp8'].includes(p.codec) ? p.codec : 'h264',
    maxKbps: num(p.maxKbps, 500, 50000, 20000),
    fps: p.fps === 30 ? 30 : 60,
    screenH: num(p.screenH, 0, 4320, 0),
    audio: p.audio !== false,
    fullRes: !!p.fullRes,
    display: typeof p.display === 'string' ? p.display : null,
  };
}

async function startCapture(rawPrefs) {
  const s = session;
  const prefs = cleanPrefs(rawPrefs);
  let display = screen.getPrimaryDisplay();
  if (prefs.display) {
    const d = screen.getAllDisplays().find((x) => String(x.id) === prefs.display);
    if (d) display = d;
  }
  const src = await sourceFor(display);
  if (session !== s) return;
  if (!src) throw new Error('no screen source available');
  s.display = display;
  s.rect = physRect(display);
  sendCapture({ t: 'start', sid: s.sid, iceServers: s.ice, source: src, displays: listDisplays(), viewOnly: s.viewOnly, prefs });
}

function sendCapture(cmd) {
  if (captureWin && !captureWin.isDestroyed()) captureWin.webContents.send('cmd', cmd);
}

function teardown(reason, keepResume) {
  const s = session;
  if (!s) return;
  session = null;
  sendCapture(reason === 'connection-lost' ? { t: 'stop' } : { t: 'bye', reason });
  injector.releaseAll();
  if (host) {
    if (reason !== 'connection-lost') host.sendSecure(s.sid, { t: 'bye', reason }).catch(() => {});
    host.endSession(s.sid, keepResume);
  }
  setDisplayAwake(false);
  showBadge(false);
  stopIdleTimer();
  updateTray();
  logLine('SESSION-END', `${short(s.sid)} ${reason} after ${((Date.now() - s.started) / 60000).toFixed(1)} min`);
  if (reason === 'idle') alert('Remote session closed because it was idle.', false);
}

// ---------------------------------------------------------------- input
function moveTo(s, x, y) {
  const r = s.rect;
  x = Math.min(1, Math.max(0, x)); y = Math.min(1, Math.max(0, y));
  injector.moveAbs(r.x + x * (r.width - 1), r.y + y * (r.height - 1));
}
// Mouse positions travel on a fast channel that may drop or reorder packets. Each carries a sequence
// number; anything older than the last applied position is ignored so the cursor never jumps back.
function freshPos(s, seq) {
  if (typeof seq !== 'number' || !isFinite(seq)) return true;
  if (seq < (s.mseq || 0)) return false;
  s.mseq = seq;
  return true;
}
function handleInput(a) {
  const s = session;
  s.lastActivity = Date.now();
  if (a[0] === 'act') return;
  if (a[0] === 'bye') { teardown('client-disconnected', false); return; }
  if (s.viewOnly) return; // enforced here, not just in the Chromebook page
  const num = (v) => typeof v === 'number' && isFinite(v);
  switch (a[0]) {
    case 'm': if (num(a[1]) && num(a[2]) && freshPos(s, a[3])) moveTo(s, a[1], a[2]); break;
    case 'r': if (num(a[1]) && num(a[2])) injector.moveRel(a[1], a[2]); break;
    case 'b':
      if (num(a[3]) && num(a[4]) && freshPos(s, a[5])) moveTo(s, a[3], a[4]);
      if (num(a[1])) injector.button(a[1], !!a[2]);
      break;
    case 'w': injector.wheel(num(a[1]) ? -a[1] : 0, num(a[2]) ? a[2] : 0); break;
    case 'k': if (typeof a[1] === 'string' && a[1].length < 32) injector.key(a[1], !!a[2]); break;
    case 'txt': if (typeof a[1] === 'string') injector.text(a[1]); break;
    case 'clip-set': if (typeof a[1] === 'string') clipboard.writeText(a[1].slice(0, 100000)); break;
    case 'rel-all': injector.releaseAll(); break;
    default: break;
  }
}

// ---------------------------------------------------------------- safety features
function panic() {
  if (session) teardown('panic', false);
  if (host) { host.setPaused(true); host.revokeAll(); }
  if (cfg) { cfg.paused = true; saveConfig(cfg); forgetDevices('panic'); }
  logLine('PAUSED', 'panic key / tray');
  alert('Remote access PAUSED. Nobody can connect until you resume it from the tray icon.', true);
  updateTray();
}
function resumeAccess() {
  if (!cfg) return;
  cfg.paused = false; saveConfig(cfg);
  if (host) host.setPaused(false);
  logLine('RESUMED', 'remote access enabled');
  updateTray();
}
function startIdleTimer() {
  stopIdleTimer();
  idleTimer = setInterval(() => {
    if (!session || !cfg) return;
    const mins = TEST && process.env.RL_IDLE_SEC ? Number(process.env.RL_IDLE_SEC) / 60 : Number(cfg.idleMinutes);
    if (mins > 0 && Date.now() - session.lastActivity > mins * 60e3) teardown('idle', false);
  }, TEST && process.env.RL_IDLE_SEC ? 1000 : 15e3);
}
function stopIdleTimer() { clearInterval(idleTimer); idleTimer = null; }
function applyKeepAwake() {
  const want = !!cfg && cfg.keepAwake !== false;
  if (want && keepAwakeId === null) keepAwakeId = powerSaveBlocker.start('prevent-app-suspension');
  if (!want && keepAwakeId !== null) { powerSaveBlocker.stop(keepAwakeId); keepAwakeId = null; }
}
function setDisplayAwake(on) {
  if (on && displayAwakeId === null) displayAwakeId = powerSaveBlocker.start('prevent-display-sleep');
  if (!on && displayAwakeId !== null) { powerSaveBlocker.stop(displayAwakeId); displayAwakeId = null; }
}
function applyLoginItem() {
  if (process.platform !== 'win32') return;
  const on = !!cfg && cfg.startWithWindows !== false;
  const args = app.isPackaged ? ['--hidden'] : [path.resolve(app.getAppPath()), '--hidden'];
  app.setLoginItemSettings({ openAtLogin: on, path: process.execPath, args });
}
function ensureStartMenuShortcut() {
  // Windows only shows notifications for apps that have a Start Menu shortcut with their AppUserModelID.
  if (process.platform !== 'win32') return;
  try {
    const lnk = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'RemoteLink.lnk');
    const args = app.isPackaged ? '' : `"${path.resolve(app.getAppPath())}"`;
    shell.writeShortcutLink(lnk, fs.existsSync(lnk) ? 'replace' : 'create', {
      target: process.execPath, args, appUserModelId: 'RemoteLink.Host', icon: asset('icon.ico'), iconIndex: 0,
      description: 'RemoteLink — control this PC from your Chromebook', cwd: path.dirname(process.execPath),
    });
  } catch (e) { logLine('WARNING', 'Start Menu shortcut: ' + e.message); }
}
function keepalive() {
  if (!cfg) return;
  // Free Supabase projects pause after a week without API traffic; one tiny read a day prevents that.
  fetch(`${cfg.signal.url}/rest/v1/keepalive?select=id&limit=1`, { headers: { apikey: cfg.signal.key }, signal: AbortSignal.timeout(10000) })
    .catch(() => {});
}

// ---------------------------------------------------------------- windows
function hardenWindow(win) {
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
}
function createCaptureWindow() {
  captureWin = new BrowserWindow({
    show: false, width: 320, height: 200, title: 'RemoteLink capture',
    webPreferences: { preload: path.join(__dirname, 'preload-capture.js'), contextIsolation: true, sandbox: true, backgroundThrottling: false },
  });
  hardenWindow(captureWin);
  captureWin.loadFile('capture.html');
  captureWin.webContents.on('render-process-gone', () => {
    logLine('CAPTURE-CRASH', 'restarting capture engine');
    if (session) teardown('connection-lost', true);
    try { captureWin.destroy(); } catch (e) { /* ignore */ }
    createCaptureWindow();
  });
}
function createBadge() {
  badgeWin = new BrowserWindow({
    width: 440, height: 36, frame: false, transparent: true, resizable: false, movable: false, focusable: false,
    skipTaskbar: true, alwaysOnTop: true, show: false, hasShadow: false, title: 'RemoteLink session',
    webPreferences: { sandbox: true, contextIsolation: true },
  });
  hardenWindow(badgeWin);
  badgeWin.setAlwaysOnTop(true, 'screen-saver');
  badgeWin.setIgnoreMouseEvents(true);
  badgeWin.setContentProtection(true); // visible on the PC, invisible in the stream
  badgeWin.loadFile('badge.html');
}
function showBadge(on) {
  if (!badgeWin || badgeWin.isDestroyed()) return;
  if (on) {
    const wa = screen.getPrimaryDisplay().workArea;
    badgeWin.setBounds({ x: Math.round(wa.x + (wa.width - 440) / 2), y: wa.y + 6, width: 440, height: 36 });
    badgeWin.showInactive();
  } else badgeWin.hide();
}
function openSetup() {
  if (setupWin) { setupWin.show(); setupWin.focus(); return; }
  setupUnlocked = false;
  setupWin = new BrowserWindow({
    width: 780, height: 900, title: 'RemoteLink — settings', backgroundColor: '#07080d', autoHideMenuBar: true,
    icon: asset('icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload-setup.js'), contextIsolation: true, sandbox: true },
  });
  hardenWindow(setupWin);
  setupWin.setContentProtection(true); // the QR / secrets never show up in a remote stream
  setupWin.loadFile('setup.html');
  setupWin.on('closed', () => { setupWin = null; setupUnlocked = false; });
}

function trayState() {
  if (!cfg) return 'off';
  if (cfg.paused) return 'paused';
  if (session) return 'active';
  return signalStatus === 'joined' ? 'idle' : 'off';
}
function updateTray() {
  if (!tray) return;
  const st = trayState();
  tray.setImage(asset(`tray-${st}.png`));
  let status = {
    off: 'Offline — reconnecting…', idle: 'Ready, waiting for your Chromebook', paused: 'PAUSED — remote access blocked',
    active: `Session active${session && session.viewOnly ? ' (view only)' : ''}${session && session.route ? ` · ${session.route.route}` : ''}`,
  }[st];
  if (!cfg) status = 'Not set up yet';
  tray.setToolTip(`${APP_NAME} — ${status}`);
  const lock = host ? host.lockedFor() : 0;
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: `${APP_NAME}: ${status}`, enabled: false },
    lock > 0 ? { label: `Logins locked for ${Math.ceil(lock / 60000)} more min`, enabled: false } : null,
    { type: 'separator' },
    session ? { label: 'Disconnect current session', click: () => teardown('host-disconnected', false) } : null,
    cfg && !cfg.paused ? { label: 'Pause remote access   (Ctrl+Alt+Shift+K)', click: panic } : null,
    cfg && cfg.paused ? { label: 'Resume remote access', click: resumeAccess } : null,
    { type: 'separator' },
    { label: cfg ? 'Settings & pairing…' : 'Set up…', click: openSetup },
    deviceList().length ? { label: `Forget trusted Chromebooks (${deviceList().length})`, click: () => forgetDevices('tray menu') } : null,
    { label: 'Activity log', click: () => { if (!fs.existsSync(LOG())) logLine('LOG', 'created'); shell.openPath(LOG()); } },
    {
      label: 'Start with Windows', type: 'checkbox', enabled: !!cfg, checked: !!cfg && cfg.startWithWindows !== false,
      click: (mi) => { cfg.startWithWindows = mi.checked; saveConfig(cfg); applyLoginItem(); },
    },
    { type: 'separator' },
    { label: 'Quit RemoteLink', click: () => app.quit() },
  ].filter(Boolean)));
}

// ---------------------------------------------------------------- IPC: capture window
const fromCapture = (e) => captureWin && !captureWin.isDestroyed() && e.sender === captureWin.webContents;
const live = (sid) => session && session.sid === sid;

ipcMain.on('cap:signal', (e, sid, msg) => {
  if (!fromCapture(e) || !live(sid) || !host || !msg || !['offer', 'ice'].includes(msg.t)) return;
  host.sendSecure(sid, msg).catch(() => {});
});
ipcMain.on('cap:input', (e, sid, a) => {
  if (!fromCapture(e) || !live(sid) || !Array.isArray(a) || typeof a[0] !== 'string') return;
  handleInput(a);
});
ipcMain.on('cap:state', (e, sid, state, info) => {
  if (!fromCapture(e) || !live(sid)) return;
  if (state === 'connected') {
    session.route = info || {};
    logLine('CONNECTED', `${short(sid)} via ${session.route.route || '?'} ${session.route.protocol || ''} from ${session.route.remote || '?'}`);
    updateTray();
  } else if (state === 'closed') {
    teardown('connection-lost', true);
  } else if (state === 'failed') {
    logLine('CAPTURE-ERROR', info && info.error);
    alert('Screen capture failed: ' + (info && info.error), true);
    teardown('capture-failed', false);
  }
});
ipcMain.on('cap:log', (e, t) => { if (fromCapture(e)) logLine('CAPTURE', String(t).slice(0, 500)); });
ipcMain.handle('cap:clipboard-get', (e, sid) => (fromCapture(e) && live(sid) ? clipboard.readText() : null));
ipcMain.handle('cap:display', async (e, sid, id) => {
  if (!fromCapture(e) || !live(sid)) return null;
  const d = screen.getAllDisplays().find((x) => String(x.id) === String(id));
  if (!d) return null;
  const src = await sourceFor(d);
  if (!src || !live(sid)) return null;
  session.display = d;
  session.rect = physRect(d);
  return src;
});

// ---------------------------------------------------------------- IPC: settings window
const fromSetup = (e) => setupWin && !setupWin.isDestroyed() && e.sender === setupWin.webContents;
const allowedSetup = (e) => fromSetup(e) && (!cfg || setupUnlocked);
const ROOM_RE = /^[a-z2-7]{24}$/;
const newRoom = () => P.base32Encode(P.rand(15)).toLowerCase();
const fmtRoom = (r) => r.match(/.{1,4}/g).join('-');

async function pairingInfo() {
  const sig = cfg.signal;
  const custom = sig.url !== DEFAULT_SIGNAL.url || sig.key !== DEFAULT_SIGNAL.key;
  let hash = `pair=${sig.room}&n=${encodeURIComponent(cfg.name)}`;
  if (custom) hash += `&u=${encodeURIComponent(sig.url)}&k=${encodeURIComponent(sig.key)}`;
  const link = cfg.clientUrl ? `${cfg.clientUrl.replace(/#.*$/, '')}#${hash}` : '';
  const qr = link ? await QRCode.toDataURL(link, { margin: 1, width: 240 }) : '';
  return { code: fmtRoom(sig.room), link, qr, custom, url: sig.url, key: sig.key, name: cfg.name };
}

ipcMain.handle('setup:status', (e) => (fromSetup(e) ? { configured: !!cfg, unlocked: !cfg || setupUnlocked, paused: !!(cfg && cfg.paused) } : null));
ipcMain.handle('setup:unlock', async (e, pw) => {
  if (!fromSetup(e) || !cfg) return { ok: false };
  if (Date.now() < unlockBlockedUntil) return { ok: false, wait: Math.ceil((unlockBlockedUntil - Date.now()) / 1000) };
  const K = await P.pbkdf2(String(pw || ''), P.unb64(cfg.secrets.salt), cfg.secrets.iter);
  setupUnlocked = P.equal(K, P.unb64(cfg.secrets.K));
  if (!setupUnlocked && ++unlockFails >= 5) { unlockFails = 0; unlockBlockedUntil = Date.now() + 60e3; }
  if (setupUnlocked) unlockFails = 0;
  return { ok: setupUnlocked };
});
ipcMain.handle('setup:load', (e) => {
  if (!allowedSetup(e)) return null;
  const c = cfg || {};
  const sig = c.signal || DEFAULT_SIGNAL;
  return {
    configured: !!cfg, name: c.name || os.hostname(), signalUrl: sig.url, signalKey: sig.key,
    turnKeyId: (c.turn && c.turn.keyId) || '', hasTurnToken: !!(c.secrets && c.secrets.turnToken),
    ntfyTopic: c.ntfyTopic || '', idleMinutes: c.idleMinutes != null ? c.idleMinutes : 20,
    allowControl: c.allowControl !== false, keepAwake: c.keepAwake !== false,
    startWithWindows: c.startWithWindows !== false, clientUrl: c.clientUrl || '',
  };
});
ipcMain.handle('setup:new-totp', async (e, name) => {
  if (!allowedSetup(e)) return null;
  const secret = P.base32Encode(P.rand(20));
  const label = encodeURIComponent(`RemoteLink:${String(name || os.hostname()).slice(0, 40)}`);
  const uri = `otpauth://totp/${label}?secret=${secret}&issuer=RemoteLink&algorithm=SHA1&digits=6&period=30`;
  const qr = await QRCode.toDataURL(uri, { margin: 1, width: 220 });
  return { secret, uri, qr };
});
async function totpMatches(secret, code) {
  code = String(code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(code)) return false;
  const key = P.base32Decode(secret);
  const c = P.totpCounter();
  for (const ctr of [c, c - 1, c + 1]) if ((await P.totpAt(key, ctr)) === code) return true;
  return false;
}
ipcMain.handle('setup:check-totp', (e, secret, code) => (allowedSetup(e) ? totpMatches(secret, code) : false));
ipcMain.handle('setup:test-turn', async (e, keyId, token) => {
  if (!allowedSetup(e)) return null;
  token = token || (cfg && cfg.secrets.turnToken);
  if (!keyId || !token) return { ok: false, error: 'Fill in both the Key ID and the API token.' };
  try {
    const list = await turnServers(String(keyId).trim(), String(token).trim());
    return { ok: true, servers: list.reduce((n, s) => n + s.urls.length, 0) };
  } catch (err) { return { ok: false, error: err.message }; }
});
ipcMain.handle('setup:test-ntfy', async (e, topic) => {
  if (!allowedSetup(e) || !/^[\w-]{6,64}$/.test(String(topic || ''))) return { ok: false };
  try {
    const r = await fetch(`https://ntfy.sh/${topic}`, { method: 'POST', body: 'Test alert from RemoteLink ✔', headers: { Title: APP_NAME } });
    return { ok: r.ok };
  } catch (err) { return { ok: false, error: err.message }; }
});
ipcMain.handle('setup:save', async (e, f) => {
  if (!allowedSetup(e) || !f) return { ok: false, error: 'Locked' };
  const errs = [];
  const name = String(f.name || '').trim().slice(0, 40);
  if (!name) errs.push('Give this PC a name.');
  const pw = String(f.password || '');
  if (!cfg && !pw) errs.push('Choose a password.');
  if (pw && pw.length < 10) errs.push('Password must be at least 10 characters (longer is better).');
  if (pw && pw !== String(f.password2 || '')) errs.push('The two passwords do not match.');
  if (!cfg && !f.totpSecret) errs.push('Set up the authenticator code.');
  if (f.totpSecret && !(await totpMatches(f.totpSecret, f.totpCode))) errs.push('The authenticator code is wrong or expired. Type the current one from your app.');
  const signalUrl = String(f.signalUrl || DEFAULT_SIGNAL.url).trim().replace(/\/+$/, '');
  if (!/^https:\/\/[\w.-]+$/.test(signalUrl)) errs.push('Signal server URL must look like https://xxxx.supabase.co');
  const signalKey = String(f.signalKey || DEFAULT_SIGNAL.key).trim();
  const ntfy = String(f.ntfyTopic || '').trim();
  if (ntfy && !/^[\w-]{6,64}$/.test(ntfy)) errs.push('Phone alert topic: 6–64 letters, numbers, - or _.');
  const clientUrl = String(f.clientUrl || '').trim();
  if (clientUrl && !/^https?:\/\/\S+$/.test(clientUrl)) errs.push('Chromebook page URL must start with https://');
  if (errs.length) return { ok: false, error: errs.join('\n') };

  const old = cfg;
  const secrets = Object.assign({}, old ? old.secrets : {});
  if (pw) {
    const salt = P.rand(16);
    secrets.salt = P.b64(salt);
    secrets.iter = P.PBKDF2_ITER;
    secrets.K = P.b64(await P.pbkdf2(pw, salt, P.PBKDF2_ITER));
  }
  if (f.totpSecret) secrets.totp = f.totpSecret;
  if (pw || f.totpSecret) secrets.devices = []; // new password/authenticator: every Chromebook must use the code again
  const turnKeyId = String(f.turnKeyId || '').trim();
  if (f.turnToken) secrets.turnToken = String(f.turnToken).trim();
  if (!turnKeyId) delete secrets.turnToken;

  const next = {
    version: 1, name,
    signal: { url: signalUrl, key: signalKey, room: old && ROOM_RE.test(old.signal.room) ? old.signal.room : newRoom() },
    turn: { keyId: turnKeyId },
    ntfyTopic: ntfy,
    idleMinutes: Math.max(0, Math.min(240, Number(f.idleMinutes) || 0)),
    allowControl: !!f.allowControl, keepAwake: !!f.keepAwake, startWithWindows: !!f.startWithWindows,
    clientUrl, paused: old ? !!old.paused : false,
    secrets,
  };
  const credsChanged = !old || pw || f.totpSecret || old.signal.url !== signalUrl || old.signal.key !== signalKey;
  saveConfig(next);
  cfg = next;
  setupUnlocked = true;
  logLine('SETTINGS', credsChanged ? 'saved (login details changed)' : 'saved');
  startHost(); // also ends any session that used the old credentials
  applyLoginItem();
  applyKeepAwake();
  keepalive();
  updateTray();
  return { ok: true, pairing: await pairingInfo() };
});
ipcMain.handle('setup:pairing', async (e) => (allowedSetup(e) && cfg ? pairingInfo() : null));
ipcMain.handle('setup:new-room', async (e) => {
  if (!allowedSetup(e) || !cfg) return null;
  cfg.signal.room = newRoom();
  cfg.secrets.devices = [];
  saveConfig(cfg);
  logLine('SETTINGS', 'new pairing code — old devices unpaired');
  startHost();
  return pairingInfo();
});
ipcMain.handle('setup:devices', (e) => (allowedSetup(e) && cfg
  ? deviceList().map((d) => ({ id: d.id, name: d.name, created: d.created, lastUsed: d.lastUsed })) : []));
ipcMain.handle('setup:forget-device', (e, id) => {
  if (!allowedSetup(e) || !cfg) return false;
  forgetDevices('settings window', id === 'all' ? null : String(id));
  return true;
});
ipcMain.handle('setup:copy', (e, t) => { if (fromSetup(e)) clipboard.writeText(String(t)); return true; });
ipcMain.handle('setup:close', (e) => { if (fromSetup(e)) setupWin.close(); return true; });

// ---------------------------------------------------------------- lifecycle
app.on('web-contents-created', (_e, wc) => wc.setWindowOpenHandler(() => ({ action: 'deny' })));
app.on('window-all-closed', () => { /* keep running in the tray */ });
app.on('will-quit', () => { globalShortcut.unregisterAll(); if (session) teardown('host-quit', false); });

app.whenReady().then(() => {
  eSession.defaultSession.setPermissionRequestHandler((wc, permission, cb, details) => {
    const ok = !!captureWin && wc === captureWin.webContents && (permission === 'media' || permission === 'display-capture');
    if (TEST) logLine('PERMISSION', `${permission} ${JSON.stringify(details && details.mediaTypes)} -> ${ok}`);
    cb(ok);
  });
  cfg = loadConfig();
  ensureStartMenuShortcut();
  tray = new Tray(asset('tray-off.png'));
  tray.on('click', () => tray.popUpContextMenu());
  tray.on('double-click', openSetup);
  createCaptureWindow();
  createBadge();
  if (!globalShortcut.register(PANIC_KEY, panic)) logLine('WARNING', `could not register panic key ${PANIC_KEY}`);
  if (TEST) process.on('SIGUSR2', panic); // test hook only
  screen.on('display-metrics-changed', () => { if (session) session.rect = physRect(session.display); });
  powerMonitor.on('lock-screen', () => sendCapture({ t: 'note', text: 'The PC just locked. Windows does not allow remote control of the lock screen.' }));
  powerMonitor.on('resume', () => { if (cfg && !session) startHost(); });

  if (cfg) {
    startHost();
    applyKeepAwake();
    applyLoginItem();
    keepalive();
    setInterval(keepalive, 12 * 3600e3);
    if (!HIDDEN && !TEST) alert('RemoteLink is running in the tray (bottom-right, near the clock).', false);
  } else {
    openSetup();
  }
  setInterval(updateTray, 60e3);
  updateTray();
  logLine('STARTED', `RemoteLink host ${app.getVersion()} (Electron ${process.versions.electron})`);
});
