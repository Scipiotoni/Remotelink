'use strict';
// Bridge for the hidden capture window. Only these calls exist; no Node access in the page.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('hostAPI', {
  onCommand: (cb) => ipcRenderer.on('cmd', (_e, cmd) => cb(cmd)),
  signal: (sid, msg) => ipcRenderer.send('cap:signal', sid, msg),
  input: (sid, arr) => ipcRenderer.send('cap:input', sid, arr),
  state: (sid, state, info) => ipcRenderer.send('cap:state', sid, state, info || null),
  log: (text) => ipcRenderer.send('cap:log', String(text)),
  clipboardGet: (sid) => ipcRenderer.invoke('cap:clipboard-get', sid),
  switchDisplay: (sid, displayId) => ipcRenderer.invoke('cap:display', sid, displayId),
});
