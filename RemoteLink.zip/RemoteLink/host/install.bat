@echo off
rem RemoteLink installer: double-click it. The real work is in install.ps1 (no admin rights needed).
title RemoteLink - install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
exit /b %errorlevel%
