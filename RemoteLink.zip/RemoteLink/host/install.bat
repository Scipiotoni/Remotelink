@echo off
setlocal
title RemoteLink - install
cd /d "%~dp0"

echo.
echo  ==== RemoteLink installer ====
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed. Installing it with winget...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
  echo.
  echo  Node.js installed. CLOSE this window and double-click install.bat again.
  pause
  exit /b 0
)

echo  Step 1/2: downloading RemoteLink components...
call npm install --omit=dev --no-audit --no-fund --ignore-scripts
if errorlevel 1 goto :failed

echo.
echo  Step 2/2: downloading the Electron engine, about 110 MB, one time...
if not exist "node_modules\electron\dist\electron.exe" call node "node_modules\electron\install.js"
if not exist "node_modules\electron\dist\electron.exe" goto :failed

echo.
echo  Done. Starting RemoteLink - the setup window will open.
echo  It also starts by itself with Windows - you can turn that off in its tray menu.
start "" "%~dp0node_modules\electron\dist\electron.exe" "%~dp0."
timeout /t 3 >nul
exit /b 0

:failed
echo.
echo  Install failed. Check your internet connection and run install.bat again.
pause
exit /b 1
