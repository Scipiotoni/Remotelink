@echo off
rem Starts RemoteLink (it runs in the system tray, next to the clock).
cd /d "%~dp0"
if not exist "node_modules\electron\package.json" goto :notinstalled
if not exist "node_modules\electron\dist\electron.exe" call node "node_modules\electron\install.js"
if not exist "node_modules\electron\dist\electron.exe" goto :notinstalled
start "" "%~dp0node_modules\electron\dist\electron.exe" "%~dp0."
exit /b 0

:notinstalled
echo RemoteLink is not fully installed yet. Run install.bat first.
pause
exit /b 1
