# RemoteLink installer for Windows. Installs into the folder this script is in.
# Used by install.bat and by the one-line web installer (client\install.ps1).
# No admin rights needed: if Node.js is missing, a private copy goes into .node\ (checksum-verified).
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$here = $PSScriptRoot
Set-Location $here
function Say($t, $c = 'Gray') { Write-Host "  $t" -ForegroundColor $c }

try {
  Write-Host ''
  Say '==== RemoteLink installer ====' Cyan
  Write-Host ''

  # an old copy from this folder must not keep files locked
  Get-Process electron -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -and $_.Path.StartsWith($here, [StringComparison]::OrdinalIgnoreCase) } |
    Stop-Process -Force -ErrorAction SilentlyContinue

  # ---- Node.js (only needed to install; RemoteLink itself runs on Electron)
  $node = $null
  $sys = Get-Command node -ErrorAction SilentlyContinue
  if ($sys) {
    $major = & $sys.Source -p "process.versions.node.split('.')[0]" 2>$null
    if ([int]"0$major" -ge 18 -and (Test-Path (Join-Path (Split-Path $sys.Source) 'node_modules\npm\bin\npm-cli.js'))) { $node = $sys.Source }
  }
  if (-not $node) {
    $priv = Join-Path $here '.node\node.exe'
    if (-not (Test-Path $priv)) {
      Say 'Step 0/2: downloading Node.js (about 30 MB, one time, no admin needed)...'
      $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
      $base = 'https://nodejs.org/dist/latest-v22.x/'
      $sums = (Invoke-WebRequest ($base + 'SHASUMS256.txt') -UseBasicParsing).Content
      $line = ($sums -split "`n") | Where-Object { $_ -match "node-v[\d.]+-win-$arch\.zip\s*$" } | Select-Object -First 1
      if (-not $line) { throw 'Could not find Node.js for this PC on nodejs.org.' }
      $hash, $file = $line.Trim() -split '\s+'
      $zip = Join-Path $env:TEMP $file
      Invoke-WebRequest ($base + $file) -OutFile $zip -UseBasicParsing
      if ((Get-FileHash $zip -Algorithm SHA256).Hash -ne $hash.ToUpper()) { throw 'The Node.js download is damaged (checksum mismatch). Run the installer again.' }
      $tmp = Join-Path $env:TEMP ('rl-node-' + [guid]::NewGuid().ToString('N'))
      Expand-Archive $zip $tmp -Force
      $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
      if (Test-Path (Join-Path $here '.node')) { Remove-Item (Join-Path $here '.node') -Recurse -Force }
      Move-Item $inner.FullName (Join-Path $here '.node')
      Remove-Item $zip, $tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
    $node = $priv
  }
  $env:Path = (Split-Path $node) + ';' + $env:Path
  $npm = Join-Path (Split-Path $node) 'node_modules\npm\bin\npm-cli.js'

  Say 'Step 1/2: downloading RemoteLink components...'
  & $node $npm install --omit=dev --no-audit --no-fund --ignore-scripts --loglevel=error
  if ($LASTEXITCODE) { throw 'Downloading the components failed. Check your internet connection.' }

  Say 'Step 2/2: downloading the Electron engine (about 110 MB, one time)...'
  $exe = Join-Path $here 'node_modules\electron\dist\electron.exe'
  if (-not (Test-Path $exe)) { & $node (Join-Path $here 'node_modules\electron\install.js') }
  if (-not (Test-Path $exe)) { throw 'Downloading Electron failed. Check your internet connection.' }

  Write-Host ''
  Say 'Done! RemoteLink is starting: its setup window opens in a moment.' Green
  Say 'It also starts by itself when you log in (you can turn that off in its tray menu).'
  if ($env:RL_NO_START -ne '1') { Start-Process $exe -ArgumentList "`"$here`""; Start-Sleep 4 }
  exit 0
} catch {
  Write-Host ''
  Say ('Install failed: ' + $_.Exception.Message) Red
  Say 'Run the installer again. If it keeps failing, see the Help section on scipiotoni.github.io/Remotelink'
  Read-Host '  Press Enter to close'
  exit 1
}
