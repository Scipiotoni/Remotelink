'use strict';
/* Hidden capture window: grabs the screen (GPU encoded by Chromium's WebRTC stack),
 * streams it to the Chromebook and forwards input events to the main process. */
(function () {
  const api = window.hostAPI;
  const MODES = {
    desktop: { hint: 'detail', degradation: 'maintain-resolution' },
    game: { hint: 'motion', degradation: 'maintain-framerate' },
  };
  const START_KBPS = 6000;

  let S = null; // current session state

  function log(t) { try { api.log(t); } catch (e) { /* ignore */ } }

  api.onCommand(async (cmd) => {
    try {
      if (cmd.t === 'start') await start(cmd);
      else if (cmd.t === 'signal') await onSignal(cmd.msg);
      else if (cmd.t === 'stop') stop();
      else if (cmd.t === 'note') sendCtl(['note', cmd.text]);
      else if (cmd.t === 'bye') {
        const cur = S;
        sendCtl(['bye', cmd.reason]);
        setTimeout(() => { if (S === cur) stop(); }, 150); // never stop a newer session
      }
    } catch (e) {
      log('capture error: ' + (e && e.stack || e));
      if (S && cmd.t === 'start') api.state(S.sid, 'failed', { error: String(e && e.message || e) });
    }
  });

  async function getStream(src, fps, audio) {
    if (window.__testStream) return window.__testStream(src, fps);
    const video = {
      mandatory: {
        chromeMediaSource: 'desktop', chromeMediaSourceId: src.sourceId,
        maxWidth: src.width, maxHeight: src.height, maxFrameRate: fps, minFrameRate: 1,
      },
    };
    if (audio) {
      try {
        return await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: 'desktop' } }, video });
      } catch (e) { log('system audio unavailable: ' + e.message); }
    }
    return navigator.mediaDevices.getUserMedia({ audio: false, video });
  }

  function codecOrder(kind, want) {
    if (!window.RTCRtpSender || !RTCRtpSender.getCapabilities) return null;
    const caps = RTCRtpSender.getCapabilities(kind);
    if (!caps) return null;
    const rank = (c) => {
      const m = c.mimeType.toLowerCase();
      const f = c.sdpFmtpLine || '';
      if (/rtx|red|ulpfec|flexfec/.test(m)) return 100;
      if (kind === 'audio') return m.includes('opus') ? 0 : 50;
      const order = { h264: ['video/h264', 'video/vp9', 'video/vp8', 'video/av1'],
        vp9: ['video/vp9', 'video/h264', 'video/vp8', 'video/av1'],
        av1: ['video/av1', 'video/h264', 'video/vp9', 'video/vp8'],
        vp8: ['video/vp8', 'video/h264', 'video/vp9', 'video/av1'] }[want] || ['video/h264', 'video/vp9', 'video/vp8', 'video/av1'];
      let r = order.indexOf(m); if (r < 0) r = 20;
      r *= 10;
      if (m === 'video/h264') {
        if (!/packetization-mode=1/.test(f)) r += 5;
        if (!/profile-level-id=42e0/.test(f)) r += 2; // constrained baseline: every HW encoder + decoder supports it
      }
      return r;
    };
    return caps.codecs.slice().sort((a, b) => rank(a) - rank(b));
  }

  async function start(cmd) {
    stop();
    S = {
      sid: cmd.sid, prefs: cmd.prefs || {}, src: cmd.source, displays: cmd.displays,
      viewOnly: cmd.viewOnly, pendingIce: [], remoteSet: false, dc: {}, disconnectTimer: null,
    };
    const s = S;
    const fps = s.prefs.fps === 30 ? 30 : 60;
    s.fps = fps;
    s.stream = await getStream(s.src, fps, s.prefs.audio !== false);
    if (S !== s) { s.stream.getTracks().forEach((t) => t.stop()); return; }
    const vTrack = s.stream.getVideoTracks()[0];
    const mode = MODES[s.prefs.mode] ? s.prefs.mode : 'desktop';
    s.mode = mode;
    vTrack.contentHint = MODES[mode].hint;

    const pc = new RTCPeerConnection({ iceServers: cmd.iceServers || [], bundlePolicy: 'max-bundle' });
    s.pc = pc;
    s.dc.ctl = pc.createDataChannel('ctl', { ordered: true });
    s.dc.mv = pc.createDataChannel('mv', { ordered: false, maxRetransmits: 0 });
    s.dc.rel = pc.createDataChannel('rel', { ordered: false });
    for (const name of ['ctl', 'mv', 'rel']) {
      const ch = s.dc[name];
      ch.onmessage = (e) => onData(s, e.data);
      if (name === 'ctl') {
        ch.onopen = () => sendCtl(['hello', {
          displays: s.displays, display: s.src.displayId, viewOnly: s.viewOnly,
          audio: s.stream.getAudioTracks().length > 0, width: s.src.width, height: s.src.height, mode, fps,
        }]);
        ch.onclose = () => { if (S === s) api.state(s.sid, 'closed', { why: 'datachannel closed' }); };
      }
    }

    const maxKbps = clampKbps(s.prefs.maxKbps);
    s.vTx = pc.addTransceiver(vTrack, {
      direction: 'sendonly', streams: [s.stream],
      sendEncodings: [{ maxBitrate: maxKbps * 1000, maxFramerate: fps, priority: 'high', networkPriority: 'high', scaleResolutionDownBy: scaleFor(s) }],
    });
    try { const o = codecOrder('video', s.prefs.codec); if (o) s.vTx.setCodecPreferences(o); } catch (e) { log('codec prefs: ' + e.message); }
    const aTrack = s.stream.getAudioTracks()[0];
    if (aTrack) {
      const aTx = pc.addTransceiver(aTrack, { direction: 'sendonly', streams: [s.stream] });
      try { const o = codecOrder('audio'); if (o) aTx.setCodecPreferences(o); } catch (e) { /* ignore */ }
    }

    pc.onicecandidate = (e) => { if (e.candidate && S === s) api.signal(s.sid, { t: 'ice', c: e.candidate.toJSON() }); };
    pc.onconnectionstatechange = () => {
      if (S !== s) return;
      const st = pc.connectionState;
      if (st === 'connected') {
        clearTimeout(s.disconnectTimer);
        if (!s.reported) { s.reported = true; routeInfo(pc).then((info) => api.state(s.sid, 'connected', info)); }
        applyParams(s);
      } else if (st === 'disconnected') {
        clearTimeout(s.disconnectTimer);
        s.disconnectTimer = setTimeout(() => { if (S === s && pc.connectionState !== 'connected') api.state(s.sid, 'closed', { why: 'network lost' }); }, 12000);
      } else if (st === 'failed' || st === 'closed') {
        api.state(s.sid, 'closed', { why: 'connection ' + st });
      }
    };

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    api.signal(s.sid, { t: 'offer', sdp: pc.localDescription.sdp });
  }

  function clampKbps(k) { k = Number(k) || 20000; return Math.max(500, Math.min(50000, k)); }

  function scaleFor(s) {
    // Send no more pixels than the Chromebook screen can show: less to encode, decode and transmit.
    const want = s.prefs.screenH > 0 ? s.prefs.screenH : 0;
    if (!want || s.prefs.fullRes) return 1;
    const r = s.src.height / want;
    return r > 1.05 ? Math.min(4, r) : 1;
  }

  // setParameters calls must not overlap (each needs its own fresh getParameters), so queue them.
  function applyParams(s) {
    s.paramChain = (s.paramChain || Promise.resolve()).then(() => applyParamsNow(s, 0));
    return s.paramChain;
  }
  async function applyParamsNow(s, attempt) {
    if (!s.vTx || S !== s) return;
    const snd = s.vTx.sender;
    try {
      const p = snd.getParameters();
      if (!p.encodings || !p.encodings.length) { if (attempt < 3) { await new Promise((r) => setTimeout(r, 300)); return applyParamsNow(s, attempt + 1); } return; }
      p.encodings[0].maxBitrate = clampKbps(s.prefs.maxKbps) * 1000;
      p.encodings[0].maxFramerate = s.fps;
      p.encodings[0].scaleResolutionDownBy = scaleFor(s);
      p.encodings[0].priority = 'high';
      p.encodings[0].networkPriority = 'high';
      p.degradationPreference = MODES[s.mode].degradation;
      await snd.setParameters(p);
    } catch (e) {
      if (attempt < 3) { await new Promise((r) => setTimeout(r, 300)); return applyParamsNow(s, attempt + 1); }
      log('setParameters: ' + e.message);
    }
    const t = snd.track; if (t) t.contentHint = MODES[s.mode].hint;
  }

  function mungeAnswer(sdp) {
    // Ask the encoder to start at a sensible bitrate instead of ramping up from ~300 kbps.
    const lines = sdp.split('\r\n');
    let inVideo = false;
    const out = [];
    const fmtpSeen = new Set();
    const pts = new Map();
    for (const l of lines) {
      if (l.startsWith('m=')) inVideo = l.startsWith('m=video');
      if (inVideo) {
        const rm = /^a=rtpmap:(\d+) ([\w-]+)\//.exec(l);
        if (rm) pts.set(rm[1], rm[2].toLowerCase());
        const fm = /^a=fmtp:(\d+) /.exec(l);
        if (fm) fmtpSeen.add(fm[1]);
      }
    }
    inVideo = false;
    const isMedia = (pt) => pts.has(pt) && !/rtx|red|ulpfec|flexfec/.test(pts.get(pt));
    const extra = `x-google-start-bitrate=${START_KBPS};x-google-min-bitrate=300`;
    for (const l of lines) {
      if (l.startsWith('m=')) inVideo = l.startsWith('m=video');
      if (inVideo) {
        const fm = /^a=fmtp:(\d+) (.*)$/.exec(l);
        if (fm && isMedia(fm[1])) { out.push(`a=fmtp:${fm[1]} ${fm[2]};${extra}`); continue; }
        out.push(l);
        const rm = /^a=rtpmap:(\d+) /.exec(l);
        if (rm && isMedia(rm[1]) && !fmtpSeen.has(rm[1])) out.push(`a=fmtp:${rm[1]} ${extra}`);
        continue;
      }
      out.push(l);
    }
    return out.join('\r\n');
  }

  async function onSignal(msg) {
    const s = S;
    if (!s || !s.pc) return;
    if (msg.t === 'answer') {
      try { await s.pc.setRemoteDescription({ type: 'answer', sdp: mungeAnswer(msg.sdp) }); }
      catch (e) { log('munged answer rejected, using original: ' + e.message); await s.pc.setRemoteDescription({ type: 'answer', sdp: msg.sdp }); }
      s.remoteSet = true;
      for (const c of s.pendingIce.splice(0)) await s.pc.addIceCandidate(c).catch(() => {});
      applyParams(s);
    } else if (msg.t === 'ice' && msg.c) {
      if (s.remoteSet) await s.pc.addIceCandidate(msg.c).catch(() => {});
      else s.pendingIce.push(msg.c);
    }
  }

  function sendCtl(arr) {
    const s = S;
    if (s && s.dc.ctl && s.dc.ctl.readyState === 'open') s.dc.ctl.send(JSON.stringify(arr));
  }

  async function onData(s, raw) {
    if (S !== s) return;
    let a;
    try { a = JSON.parse(raw); } catch (e) { return; }
    if (!Array.isArray(a) || typeof a[0] !== 'string') return;
    switch (a[0]) {
      case 'ping':
        sendCtl(['pong', a[1]]);
        if (a[2]) api.input(s.sid, ['act']);
        return;
      case 'mode':
        if (MODES[a[1]]) { s.mode = a[1]; applyParams(s); }
        return;
      case 'br':
        s.prefs.maxKbps = clampKbps(a[1]); applyParams(s);
        return;
      case 'fps':
        s.fps = a[1] === 30 ? 30 : 60; applyParams(s);
        return;
      case 'fullres':
        s.prefs.fullRes = !!a[1]; applyParams(s);
        return;
      case 'clip-get': {
        const text = await api.clipboardGet(s.sid);
        if (typeof text === 'string') sendCtl(['clip', text.slice(0, 100000)]);
        return;
      }
      case 'disp': {
        const src = await api.switchDisplay(s.sid, a[1]);
        if (!src || S !== s) return;
        const ns = await getStream(src, s.fps, false);
        const nt = ns.getVideoTracks()[0];
        nt.contentHint = MODES[s.mode].hint;
        const old = s.vTx.sender.track;
        await s.vTx.sender.replaceTrack(nt);
        if (old) old.stop();
        s.src = src;
        applyParams(s);
        sendCtl(['disp', src.displayId, src.width, src.height]);
        return;
      }
      default:
        api.input(s.sid, a); // main process validates (view-only, session) and injects
    }
  }

  async function routeInfo(pc) {
    try {
      const st = await pc.getStats();
      let pair = null;
      st.forEach((r) => { if (r.type === 'transport' && r.selectedCandidatePairId) pair = st.get(r.selectedCandidatePairId); });
      if (!pair) st.forEach((r) => { if (r.type === 'candidate-pair' && r.nominated && r.state === 'succeeded') pair = r; });
      if (!pair) return {};
      const l = st.get(pair.localCandidateId) || {};
      const r = st.get(pair.remoteCandidateId) || {};
      return {
        route: (l.candidateType === 'relay' || r.candidateType === 'relay') ? 'relay' : 'direct',
        protocol: l.relayProtocol || l.protocol, remote: r.address || r.ip || '', remoteType: r.candidateType,
      };
    } catch (e) { return {}; }
  }

  function stop() {
    const s = S;
    S = null;
    if (!s) return;
    clearTimeout(s.disconnectTimer);
    try { if (s.dc.ctl && s.dc.ctl.readyState === 'open') s.dc.ctl.onclose = null; } catch (e) { /* ignore */ }
    try { s.pc && s.pc.close(); } catch (e) { /* ignore */ }
    try { s.stream && s.stream.getTracks().forEach((t) => t.stop()); } catch (e) { /* ignore */ }
  }
})();
