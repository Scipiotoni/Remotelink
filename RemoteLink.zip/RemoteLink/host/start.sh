#!/usr/bin/env bash
# Starts RemoteLink (macOS menu bar / Linux system tray). Already running? Then this restarts its connection.
# Extra arguments are passed on (settings.sh uses --settings).
cd "$(dirname "$0")"
DIR="$(pwd)"
[ -x "$DIR/.node/bin/node" ] && export PATH="$DIR/.node/bin:$PATH"
EL="$(node -p "try { require('./node_modules/electron') } catch (e) { '' }" 2>/dev/null)"
if [ -z "$EL" ] || [ ! -e "$EL" ]; then
  echo "RemoteLink is not fully installed yet. Run:  bash \"$DIR/install.sh\""
  exit 1
fi
if [ "$(uname -s)" = Darwin ]; then
  # Start through LaunchServices so macOS asks for permissions for "Electron" itself, not for Terminal.
  APP="${EL%/Contents/MacOS/*}"
  open -n -g -a "$APP" --args "$DIR" "$@"
  echo "RemoteLink started (menu bar, top-right)."
  exit 0
fi
ARGS=()
if [ "$(uname -s)" = Linux ]; then
  ARGS+=(--ozone-platform=x11) # X11 is needed to see and control the screen
  # Chromium's sandbox needs unprivileged user namespaces; if the kernel forbids them, run without it.
  if [ "$(cat /proc/sys/kernel/unprivileged_userns_clone 2>/dev/null)" = 0 ] || \
     [ "$(cat /proc/sys/kernel/apparmor_restrict_unprivileged_userns 2>/dev/null)" = 1 ]; then
    ARGS+=(--no-sandbox)
  fi
fi
nohup "$EL" "$DIR" "${ARGS[@]}" "$@" >/dev/null 2>&1 &
echo "RemoteLink started."
