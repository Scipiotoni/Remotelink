'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('setupAPI', {
  status: () => ipcRenderer.invoke('setup:status'),
  unlock: (password) => ipcRenderer.invoke('setup:unlock', password),
  load: () => ipcRenderer.invoke('setup:load'),
  newTotp: (name) => ipcRenderer.invoke('setup:new-totp', name),
  checkTotp: (secret, code) => ipcRenderer.invoke('setup:check-totp', secret, code),
  testTurn: (keyId, token) => ipcRenderer.invoke('setup:test-turn', keyId, token),
  testShared: () => ipcRenderer.invoke('setup:test-shared'),
  testNtfy: (topic) => ipcRenderer.invoke('setup:test-ntfy', topic),
  save: (form) => ipcRenderer.invoke('setup:save', form),
  pairing: () => ipcRenderer.invoke('setup:pairing'),
  newRoom: () => ipcRenderer.invoke('setup:new-room'),
  devices: () => ipcRenderer.invoke('setup:devices'),
  forgetDevice: (id) => ipcRenderer.invoke('setup:forget-device', id),
  copy: (text) => ipcRenderer.invoke('setup:copy', text),
  close: () => ipcRenderer.invoke('setup:close'),
});
