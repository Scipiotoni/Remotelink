#!/usr/bin/env bash
# RemoteLink installer for macOS and Linux. Run it with:  bash install.sh
# Installs into this folder only (no sudo): a private Node.js if needed, the app's parts and the Electron engine.
set -euo pipefail
cd "$(dirname "$0")"
DIR="$(pwd)"
OS="$(uname -s)"; ARCH="$(uname -m)"

echo
echo " ==== RemoteLink installer ($OS $ARCH) ===="
echo

case "$OS" in
  Darwin) PLAT=darwin ;;
  Linux) PLAT=linux ;;
  *) echo " Sorry, this installer is for macOS and Linux. On Windows use install.bat."; exit 1 ;;
esac
case "$ARCH" in
  x86_64|amd64) NARCH=x64 ;;
  arm64|aarch64) NARCH=arm64 ;;
  *) echo " Sorry, $ARCH processors are not supported."; exit 1 ;;
esac

# An older RemoteLink from this folder must not be running while its files are replaced.
pkill -f "$DIR/node_modules/electron/dist" 2>/dev/null && { echo " Stopped the running RemoteLink."; sleep 1; } || true

if [ "$PLAT" = linux ]; then
  missing=""
  LIBS="$(ldconfig -p 2>/dev/null || true)"
  for lib in libXtst.so.6 libnss3.so libgtk-3.so.0 libasound.so.2; do
    case "$LIBS" in *"$lib"*) ;; *) missing="$missing $lib" ;; esac
  done
  if [ -n "$missing" ]; then
    echo " Missing system libraries:$missing"
    echo " On Arch Linux install them with:"
    echo "   sudo pacman -S --needed libxtst nss gtk3 alsa-lib"
    echo " then run this installer again."
    exit 1
  fi
fi

# ---- Node.js: use the system one if it is new enough, else a private copy in ./.node
NODE_OK=0
if command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1; then
  [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ] && NODE_OK=1
fi
if [ "$NODE_OK" = 0 ] && [ ! -x "$DIR/.node/bin/node" ]; then
  echo " Step 0/2: downloading Node.js (about 50 MB, only once)..."
  BASE="https://nodejs.org/dist/latest-v22.x"
  SUMS="$(curl -fsSL "$BASE/SHASUMS256.txt")"
  FILE="$(printf '%s\n' "$SUMS" | awk -v want="-$PLAT-$NARCH.tar.gz" 'substr($2, length($2) - length(want) + 1) == want && $2 ~ /^node-v/ { print $2 }' | sed -n 1p)"
  [ -n "$FILE" ] || { echo " Could not find Node.js for $PLAT-$NARCH."; exit 1; }
  WANT="$(printf '%s\n' "$SUMS" | awk -v f="$FILE" '$2 == f { print $1 }')"
  TMP="$(mktemp -d)"
  curl -fL --progress-bar "$BASE/$FILE" -o "$TMP/node.tgz"
  if command -v sha256sum >/dev/null 2>&1; then GOT="$(sha256sum "$TMP/node.tgz" | awk '{print $1}')"; else GOT="$(shasum -a 256 "$TMP/node.tgz" | awk '{print $1}')"; fi
  [ "$GOT" = "$WANT" ] || { echo " Node.js download is corrupt (checksum mismatch). Run the installer again."; rm -rf "$TMP"; exit 1; }
  rm -rf "$DIR/.node"; mkdir -p "$DIR/.node"
  tar -xzf "$TMP/node.tgz" -C "$DIR/.node" --strip-components=1
  rm -rf "$TMP"
fi
[ -x "$DIR/.node/bin/node" ] && export PATH="$DIR/.node/bin:$PATH"

echo " Step 1/2: downloading RemoteLink components..."
npm install --omit=dev --no-audit --no-fund --ignore-scripts

echo
echo " Step 2/2: downloading the Electron engine (about 110 MB, only once)..."
EL="$(node -p "try { require('./node_modules/electron') } catch (e) { '' }")"
if [ -z "$EL" ] || [ ! -e "$EL" ]; then node node_modules/electron/install.js; fi
EL="$(node -p "require('./node_modules/electron')")"
[ -e "$EL" ] || { echo " Install failed: the Electron engine is missing. Check the internet connection and run again."; exit 1; }

chmod +x "$DIR"/*.sh 2>/dev/null || true
echo
echo " Done. Starting RemoteLink - the settings window will open."
if [ "$PLAT" = darwin ]; then
  echo " macOS will ask for Screen Recording and Accessibility permission for \"Electron\": allow both,"
  echo " then quit RemoteLink from its menu-bar icon and start it again:  bash \"$DIR/start.sh\""
else
  if [ "${XDG_SESSION_TYPE:-}" = wayland ]; then
    echo " WARNING: this is a Wayland session. RemoteLink needs an X11 session to see and control the screen."
    echo " Log out, pick an X11/Xorg session at the login screen (e.g. \"Plasma (X11)\"), and start it again."
  fi
  echo " Settings later:  bash \"$DIR/settings.sh\""
fi
bash "$DIR/start.sh"
