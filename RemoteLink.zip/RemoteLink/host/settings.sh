#!/usr/bin/env bash
# Opens RemoteLink's settings window (useful when the desktop has no tray icon). Starts RemoteLink if needed.
exec bash "$(dirname "$0")/start.sh" --settings
