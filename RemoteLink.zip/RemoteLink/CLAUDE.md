# RemoteLink — notes for Claude Code

Remote desktop: control a Windows PC from a (school) Chromebook browser, low latency, from anywhere.

## Layout
- `host/` — Windows tray app (Electron 45). `main.js` = tray, settings, sessions, input; `capture.js` = hidden window that captures the screen (`chromeMediaSource: 'desktop'`) and streams it with WebRTC (H.264 preferred, GPU-encoded); `lib/signal-host.js` = login + signaling state machine; `lib/proto.js` = crypto (WebCrypto only); `lib/rt.js` = minimal Supabase Realtime (Phoenix vsn 1.0.0) broadcast client; `lib/input-win.js` + `lib/keymap.js` = SendInput via koffi (scancodes, absolute mouse over the virtual desktop).
- `client/app.html` — the whole Chromebook app in ONE file (no build step for the user).
- `client/index.html` — landing page (description, setup, security, download). Redirects old `…/#pair=…` links to `app.html`.
- GitHub Pages repo `Scipiotoni/Remotelink` (https://scipiotoni.github.io/Remotelink/) holds `index.html`, `app.html`, `RemoteLink.zip` and `.nojekyll` at the root, branch `main`. Bump the version label (landing footer + app login footer, currently v1.4.5) on every release so it's obvious which version is live.
- User data: `%APPDATA%\RemoteLink\` → `config.json` (secrets encrypted with DPAPI via safeStorage), `state.json` (lockout), `activity.log` (human-readable). Never print or commit these.

## Protocol (both sides must match)
- Signaling: Supabase project `sbpbamajbbwuxjjcnkkl` (https://sbpbamajbbwuxjjcnkkl.supabase.co), publishable key `sb_publishable_x9imtiSPZ9dPatRD__5rBA_adoHUHvZ` (public by design). Public broadcast channel `realtime:rl:<room>`, event `sig`. Room = 24 chars base32 (the pairing code). A tiny `public.keepalive` table is pinged daily so the free project doesn't pause.
- Login: `hello{cn}` → `challenge{hn,salt,iter}` → `auth{mode,proof}`. Modes: `otp` (PBKDF2-600k password key K + TOTP code), `device` (K + trusted-device key, issued after an otp login with `remember`), `resume` (10-min token after a network drop). Everything after login is AES-256-GCM sealed (`sec` messages) with a per-session key. 5 failures → lockout (15 min, doubling).
- Datachannels: `ctl` (ordered/reliable), `mv` (unordered, maxRetransmits 0: absolute mouse with sequence numbers), `rel` (unordered/reliable: relative mouse for game mode).
- Optional Cloudflare TURN (keys in the app settings) — credentials generated on the PC and sent sealed. Remote setup without typing at the PC: start RemoteLink with `RL_IMPORT_TURN=<file with the JSON from cf realtime turn keys create>` → tests the key, stores it encrypted, logs `TURN-IMPORT` (never the values).
- Sealed messages carry a counter `n`. Both sides SEND in order (per-session promise chain: WebCrypto is async and Node runs it on a thread pool, so a small ICE message could overtake the big offer/answer) and RECEIVE with a 64-wide replay window (`SignalHost.fresh` / `fresh()` in app.html), never a strict `n > last` check — that dropped offers/answers and the video never started.
- `welcome.resumeAfterBye` = PC is in "Always active" mode: a Chromebook "bye" keeps the 10-min resume token (Reconnect button). Wrong/expired resume tokens don't count toward the lockout.
- Auto-connect (opt-in per Chromebook): the client stores `pair.dev.ak` = `deviceSecret(deviceKey, K)` and logs in in `device` mode without PBKDF2. Same proof on the wire; revoked by forgetting the device on the PC. A refused key is deleted immediately (refusals count toward lockout). Never auto-reconnect after the PC sent `bye`.
- Troubleshooting: sealed `{t:'diag'}` from a logged-in client → PC replies `{t:'diag', host:{…settings summary…}, log:[last 60 activity-log lines]}` (no secrets; TURN creds reduced to a count). The client's 🩺 panel also runs a no-login probe (`hello` → challenge/paused/locked/silent) and a STUN test.

## Gotchas (learned the hard way)
1. Electron 45 does NOT download its binary during `npm install`. Always run `node node_modules\electron\install.js` afterwards and check `node_modules\electron\dist\electron.exe` exists. `install.bat` / `start.bat` do this.
2. This npm blocks install scripts (allowScripts). Use `npm install --omit=dev --no-audit --no-fund --ignore-scripts`. koffi loads its prebuilt binary from `node_modules\@koromix\koffi-win32-x64` — no script needed.
3. `client/app.html` contains INLINED copies of `host/lib/proto.js` and `host/lib/rt.js` (its first two `<script>` blocks). Change a lib file → update the inlined copy too, or PC and Chromebook stop understanding each other.
4. Electron permission for desktop capture is `display-capture` (allowed only for the capture window).
5. Only one instance runs. Quit from the tray (right-click → Quit RemoteLink) or `taskkill /IM electron.exe /F` before reinstalling.
6. Don't unzip an old `RemoteLink.zip` over the folder — it restores old files.
7. Validate every JS file with `node --check` (and the inline scripts of `client/app.html` and `client/index.html`) before delivering.
8. GitHub Pages caches pages ~10 min; after pushing, wait 1–2 min and hard-reload (Ctrl+Shift+R). The version label tells you what is live.

## Style
Single-file HTML for the client, dark/neon UI, keyboard-driven. Test hooks in `main.js` only run with `RL_TEST=1`.
