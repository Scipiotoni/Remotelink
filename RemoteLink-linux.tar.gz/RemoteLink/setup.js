'use strict';
(function () {
  const api = window.setupAPI;
  const $ = (id) => document.getElementById(id);
  const show = (id, on) => $(id).classList.toggle('hidden', !on);
  const msg = (id, text, ok) => { const el = $(id); el.textContent = text || ''; el.className = 'msg ' + (ok ? 'ok' : ok === false ? 'bad' : ''); };

  let state = { configured: false, totp: null, totpOk: false };

  async function init() {
    const st = await api.status();
    state.configured = st.configured;
    if (st.configured && !st.unlocked) { show('unlock', true); $('unlockPw').focus(); return; }
    if (st.configured) return showPairing();
    await loadForm();
  }

  $('unlockBtn').onclick = unlock;
  $('unlockPw').addEventListener('keydown', (e) => { if (e.key === 'Enter') unlock(); });
  async function unlock() {
    msg('unlockMsg', 'Checking…');
    const r = await api.unlock($('unlockPw').value);
    $('unlockPw').value = '';
    if (r.ok) { show('unlock', false); msg('unlockMsg', ''); showPairing(); }
    else msg('unlockMsg', r.wait ? `Too many tries. Wait ${r.wait} s.` : 'Wrong password.', false);
  }

  async function loadForm() {
    const f = await api.load();
    if (!f) return;
    show('pairing', false);
    show('form', true);
    $('name').value = f.name;
    $('turnKeyId').value = f.turnKeyId;
    $('turnToken').value = '';
    $('turnToken').placeholder = f.hasTurnToken ? 'saved — leave empty to keep' : '';
    $('ntfyTopic').value = f.ntfyTopic;
    $('idleMinutes').value = f.idleMinutes;
    $('allowControl').checked = f.allowControl;
    $('keepAwake').checked = f.keepAwake;
    $('startWithWindows').checked = f.startWithWindows;
    if (f.platform && f.platform !== 'win32') $('startWithLabel').textContent = 'Start RemoteLink when I log in';
    $('alwaysActive').checked = !!f.alwaysActive;
    $('clientUrl').value = f.clientUrl;
    $('signalUrl').value = f.signalUrl;
    $('signalKey').value = f.signalKey;
    $('pw').placeholder = f.configured ? 'leave empty to keep current' : '';
    $('pw2').placeholder = $('pw').placeholder;
    if (f.configured) { $('pwHint').textContent = 'Leave both empty to keep your current password.'; show('totpExisting', true); show('totpNew', false); }
    else await newTotp();
    $('name').focus();
  }

  async function newTotp() {
    state.totp = await api.newTotp($('name').value);
    state.totpOk = false;
    $('qr').src = state.totp.qr;
    $('secret').textContent = state.totp.secret.match(/.{1,4}/g).join(' ');
    $('totpCode').value = '';
    msg('totpMsg', '');
    show('totpExisting', false);
    show('totpNew', true);
  }
  $('totpReset').onclick = newTotp;

  $('totpCheck').onclick = checkTotp;
  $('totpCode').addEventListener('input', () => { if ($('totpCode').value.replace(/\D/g, '').length === 6) checkTotp(); });
  async function checkTotp() {
    const ok = await api.checkTotp(state.totp.secret, $('totpCode').value);
    state.totpOk = ok;
    msg('totpMsg', ok ? '✔ Authenticator works.' : '✖ Wrong code. Use the current code (it changes every 30 s).', ok);
  }

  $('turnTest').onclick = async () => {
    msg('turnMsg', 'Testing…');
    const r = await api.testTurn($('turnKeyId').value.trim(), $('turnToken').value.trim());
    msg('turnMsg', r.ok ? `✔ Cloudflare relay works (${r.servers} server addresses).` : '✖ ' + r.error, r.ok);
  };
  $('ntfyTest').onclick = async () => {
    const r = await api.testNtfy($('ntfyTopic').value.trim());
    msg('ntfyMsg', r.ok ? '✔ Sent. Check your phone.' : '✖ Could not send (topic must be 6–64 letters/numbers/-/_).', r.ok);
  };

  async function save() {
    if (state.totp && !state.totpOk) { msg('saveMsg', 'Check the authenticator code first (step 3).', false); $('totpCode').focus(); return; }
    msg('saveMsg', 'Saving…');
    const r = await api.save({
      name: $('name').value, password: $('pw').value, password2: $('pw2').value,
      totpSecret: state.totp ? state.totp.secret : null, totpCode: $('totpCode').value,
      turnKeyId: $('turnKeyId').value, turnToken: $('turnToken').value,
      ntfyTopic: $('ntfyTopic').value, idleMinutes: $('idleMinutes').value,
      allowControl: $('allowControl').checked, keepAwake: $('keepAwake').checked, startWithWindows: $('startWithWindows').checked, alwaysActive: $('alwaysActive').checked,
      clientUrl: $('clientUrl').value, signalUrl: $('signalUrl').value, signalKey: $('signalKey').value,
    });
    if (!r.ok) { msg('saveMsg', r.error, false); return; }
    $('pw').value = ''; $('pw2').value = '';
    state.totp = null; state.totpOk = false; state.configured = true;
    msg('saveMsg', '');
    renderPairing(r.pairing);
  }
  $('saveBtn').onclick = save;
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); if (!$('form').classList.contains('hidden')) save(); }
    if (e.key === 'Escape') api.close();
  });
  $('closeBtn').onclick = () => api.close();

  async function showPairing() { renderPairing(await api.pairing()); }
  function renderPairing(p) {
    if (!p) return;
    show('form', false);
    show('pairing', true);
    $('pairCode').textContent = p.code;
    show('pairLinkBox', !!p.link);
    if (p.link) { $('pairQr').src = p.qr; $('pairLink').textContent = p.link; }
    show('pairCustom', p.custom);
    if (p.custom) $('pairCustom').textContent = `Custom signal server in use — use the pairing link, or enter URL ${p.url} and key ${p.key} on the Chromebook.`;
    $('copyCode').onclick = () => api.copy(p.code);
    $('copyLink').onclick = () => api.copy(p.link);
    renderDevices();
  }

  async function renderDevices() {
    const list = await api.devices();
    const box = $('devList');
    box.textContent = '';
    const when = (t) => new Date(t).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
    if (!list.length) {
      const p = document.createElement('p'); p.className = 'hint'; p.textContent = 'None yet. Tick "Remember this Chromebook" when you log in with the code.';
      box.appendChild(p);
      return;
    }
    for (const d of list) {
      const row = document.createElement('div'); row.className = 'dev';
      const name = document.createElement('b'); name.textContent = d.name;
      const info = document.createElement('small'); info.textContent = `added ${when(d.created)} · last used ${when(d.lastUsed)}`;
      const btn = document.createElement('button'); btn.textContent = 'Remove';
      btn.onclick = async () => { await api.forgetDevice(d.id); renderDevices(); };
      row.append(name, info, btn);
      box.appendChild(row);
    }
    if (list.length > 1) {
      const all = document.createElement('button'); all.textContent = 'Remove all'; all.style.marginTop = '6px';
      all.onclick = async () => { await api.forgetDevice('all'); renderDevices(); };
      box.appendChild(all);
    }
  }
  $('editBtn').onclick = loadForm;
  $('newRoom').onclick = async () => {
    if (!confirm('Make a new pairing code? Every paired Chromebook will need the new code.')) return;
    renderPairing(await api.newRoom());
  };

  init();
})();
